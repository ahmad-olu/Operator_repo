class Displayname extends ValueObject<String> {
  @override
  final Either<ValueFailure<String>, String> value;

  factory Displayname(String input) {
    return Displayname._(
      validateDisplayname(input).flatMap(validateStringNotEmpty),
    );
  }

  const Displayname._(this.value);
}

class Followers extends ValueObject<int> {
  @override
  final Either<ValueFailure<int>, int> value;
  factory Followers(int input) {
    return Followers._(validateintegerNotNegative(input));
  }
  const Followers._(this.value);
}

class Following extends ValueObject<int> {
  @override
  final Either<ValueFailure<int>, int> value;
  factory Following(int input) {
    return Following._(validateintegerNotNegative(input));
  }
  const Following._(this.value);
}
